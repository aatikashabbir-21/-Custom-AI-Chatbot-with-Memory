"""
Custom AI Chatbot with Memory — Terminal Version (Bonus)
----------------------------------------------------------
A command-line version of the same chatbot, showing that the "memory"
technique (resending the full conversation history on every request) is
independent of whether the interface is a terminal or a web app.

LLM provider: Groq API (OpenAI-compatible chat completions endpoint).

Commands available while chatting:
    /clear   -> wipes the conversation history (starts fresh)
    /save    -> saves the current conversation to a JSON file
    /history -> shows how many messages are currently stored
    /exit    -> quits the program
"""

import os
import sys
import json
from datetime import datetime

from dotenv import load_dotenv
from groq import Groq, APIError, APIConnectionError, AuthenticationError

load_dotenv()

MODEL_NAME = "llama-3.3-70b-versatile"
MAX_MESSAGES = 20  # bonus: limit stored messages to avoid token limits
CONVERSATIONS_DIR = "conversations"
os.makedirs(CONVERSATIONS_DIR, exist_ok=True)

# The in-memory conversation history — a simple Python list.
conversation_history = []


def get_client():
    api_key = os.getenv("GROQ_API_KEY")
    if not api_key or api_key.strip() == "" or api_key == "your_key_here":
        return None
    return Groq(api_key=api_key)


def trim_history():
    global conversation_history
    if len(conversation_history) > MAX_MESSAGES:
        conversation_history = conversation_history[-MAX_MESSAGES:]


def save_conversation():
    if not conversation_history:
        print("Nothing to save yet.\n")
        return
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = os.path.join(CONVERSATIONS_DIR, f"conversation_{timestamp}.json")
    with open(filename, "w", encoding="utf-8") as f:
        json.dump(conversation_history, f, indent=2, ensure_ascii=False)
    print(f"✅ Conversation saved to {filename}\n")


def call_llm(client, user_input):
    conversation_history.append({"role": "user", "content": user_input})
    trim_history()

    # Groq uses the OpenAI-compatible chat completions format, so the
    # system prompt is just another message at the front of the list.
    api_messages = [
        {"role": "system", "content": "You are a helpful, friendly AI assistant "
                                       "in a terminal chatbot. Keep answers "
                                       "concise and conversational."}
    ] + conversation_history

    response = client.chat.completions.create(
        model=MODEL_NAME,
        max_tokens=1024,
        messages=api_messages,
    )

    ai_reply = response.choices[0].message.content
    conversation_history.append({"role": "assistant", "content": ai_reply})
    trim_history()
    return ai_reply


def main():
    print("=" * 60)
    print("🤖  Custom AI Chatbot with Memory (Terminal Edition)")
    print("=" * 60)
    print("Type your message and press Enter.")
    print("Commands: /clear  /save  /history  /exit\n")

    client = get_client()
    if client is None:
        print("⚠️  No valid API key found.")
        print("Please add GROQ_API_KEY=your_key_here to your .env file.\n")
        sys.exit(1)

    while True:
        try:
            user_input = input("You: ").strip()
        except (KeyboardInterrupt, EOFError):
            print("\nGoodbye! 👋")
            break

        if not user_input:
            continue

        if user_input.lower() == "/exit":
            print("Goodbye! 👋")
            break

        elif user_input.lower() == "/clear":
            conversation_history.clear()
            print("🗑️  Conversation history cleared.\n")
            continue

        elif user_input.lower() == "/save":
            save_conversation()
            continue

        elif user_input.lower() == "/history":
            print(f"📝 Messages currently in memory: {len(conversation_history)}\n")
            continue

        # Normal chat message -> call the LLM with full error handling
        try:
            reply = call_llm(client, user_input)
            print(f"AI: {reply}\n")

        except AuthenticationError:
            print("⚠️  Authentication failed. Check your GROQ_API_KEY.\n")

        except APIConnectionError:
            print("⚠️  Network error: could not reach the Groq API. "
                  "Check your internet connection.\n")

        except APIError as e:
            print(f"⚠️  API error: {e}\n")

        except Exception as e:
            print(f"⚠️  Unexpected error: {e}\n")


if __name__ == "__main__":
    main()
