"""
Custom AI Chatbot with Memory
------------------------------
A Streamlit web application that demonstrates how to build a chatbot which
remembers previous messages during a session and uses that history as
context for every new response sent to the LLM (Groq API).

Core learning objective:
    Maintain an in-memory conversation history (a Python list) and append
    every new user message + AI response to it BEFORE sending the next
    request to the model. This list is what gets sent back to the API
    every single time, which is how the model "remembers" the conversation.

LLM provider: Groq API (OpenAI-compatible chat completions endpoint).
"""

import os
import json
from datetime import datetime

import streamlit as st
from dotenv import load_dotenv
from groq import Groq, APIError, APIConnectionError, AuthenticationError

# --------------------------------------------------------------------------
# 1. SETUP
# --------------------------------------------------------------------------

load_dotenv()  # reads the .env file and loads GROQ_API_KEY into env vars

st.set_page_config(page_title="AI Chatbot with Memory", page_icon="🤖", layout="centered")

MODEL_NAME = "llama-3.3-70b-versatile"
DEFAULT_MAX_MESSAGES = 20   # bonus: limit stored messages to avoid hitting token limits
CONVERSATIONS_DIR = "conversations"

os.makedirs(CONVERSATIONS_DIR, exist_ok=True)


# --------------------------------------------------------------------------
# 2. SESSION STATE (this IS the "memory" of the chatbot)
# --------------------------------------------------------------------------
# st.session_state persists across Streamlit reruns for the same browser
# session, which is exactly what we need to hold conversation history
# for as long as the user is on the page.

if "messages" not in st.session_state:
    # Each item: {"role": "user" | "assistant", "content": "..."}
    st.session_state.messages = []

if "max_messages" not in st.session_state:
    st.session_state.max_messages = DEFAULT_MAX_MESSAGES


# --------------------------------------------------------------------------
# 3. HELPER FUNCTIONS
# --------------------------------------------------------------------------

def get_client():
    """Create the Groq API client, handling a missing key gracefully."""
    api_key = os.getenv("GROQ_API_KEY")
    if not api_key or api_key.strip() == "" or api_key == "your_key_here":
        return None
    return Groq(api_key=api_key)


def trim_history():
    """
    Bonus feature: limit stored messages to avoid exceeding the model's
    token limit. We keep only the most recent N messages while always
    keeping the conversation in valid user/assistant pairs.
    """
    limit = st.session_state.max_messages
    if len(st.session_state.messages) > limit:
        st.session_state.messages = st.session_state.messages[-limit:]


def call_llm(user_input: str) -> str:
    """
    Sends the ENTIRE conversation history (previous messages + the new one)
    to the LLM. This is the key trick behind "memory": the model itself is
    stateless, so WE resend the whole context every single time.
    """
    client = get_client()
    if client is None:
        raise ValueError(
            "No valid API key found. Please add GROQ_API_KEY to your .env file."
        )

    # Append the new user message to memory BEFORE calling the model
    st.session_state.messages.append({"role": "user", "content": user_input})
    trim_history()

    # Groq uses the OpenAI-compatible chat completions format, so the
    # system prompt is just another message at the front of the list.
    api_messages = [
        {"role": "system", "content": "You are a helpful, friendly AI assistant "
                                       "in a chatbot app. Keep answers concise "
                                       "and conversational."}
    ] + st.session_state.messages  # <-- full history sent as context

    response = client.chat.completions.create(
        model=MODEL_NAME,
        max_tokens=1024,
        messages=api_messages,
    )

    ai_reply = response.choices[0].message.content

    # Append the AI's reply to memory too, so future turns remember it
    st.session_state.messages.append({"role": "assistant", "content": ai_reply})
    trim_history()

    return ai_reply


def save_conversation_to_file():
    """Bonus feature: save the current conversation history to a JSON file."""
    if not st.session_state.messages:
        return None
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = os.path.join(CONVERSATIONS_DIR, f"conversation_{timestamp}.json")
    with open(filename, "w", encoding="utf-8") as f:
        json.dump(st.session_state.messages, f, indent=2, ensure_ascii=False)
    return filename


def conversation_as_text() -> str:
    """Builds a human-readable transcript, used for the download button."""
    lines = []
    for msg in st.session_state.messages:
        speaker = "You" if msg["role"] == "user" else "AI"
        lines.append(f"{speaker}: {msg['content']}")
    return "\n\n".join(lines)


# --------------------------------------------------------------------------
# 4. SIDEBAR — controls & bonus features
# --------------------------------------------------------------------------

with st.sidebar:
    st.header("⚙️ Settings")

    api_key_present = get_client() is not None
    if api_key_present:
        st.success("API key loaded ✅")
    else:
        st.error("No API key found. Add GROQ_API_KEY to your .env file.")

    st.session_state.max_messages = st.slider(
        "Max messages to remember (token limit control)",
        min_value=4, max_value=50,
        value=st.session_state.max_messages, step=2,
        help="Older messages are dropped once this limit is reached, "
             "to keep the conversation within the model's token limit."
    )

    st.divider()

    col1, col2 = st.columns(2)
    with col1:
        if st.button("🗑️ Clear Chat", use_container_width=True):
            st.session_state.messages = []
            st.rerun()
    with col2:
        if st.button("💾 Save Chat", use_container_width=True):
            path = save_conversation_to_file()
            if path:
                st.success(f"Saved to {path}")
            else:
                st.warning("Nothing to save yet.")

    if st.session_state.messages:
        st.download_button(
            "⬇️ Download Transcript (.txt)",
            data=conversation_as_text(),
            file_name=f"chat_transcript_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt",
            use_container_width=True,
        )

    st.divider()
    st.caption(f"Messages currently in memory: {len(st.session_state.messages)}")
    st.caption("Built with Streamlit + Groq API")


# --------------------------------------------------------------------------
# 5. MAIN CHAT INTERFACE
# --------------------------------------------------------------------------

st.title("🤖 Custom AI Chatbot with Memory")
st.caption("This chatbot remembers everything you say during this session "
           "and uses it as context for every new reply.")

# Render the full chat history on every rerun
for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])

# Chat input box
user_input = st.chat_input("Type your message here...")

if user_input:
    # Show the user's message immediately
    with st.chat_message("user"):
        st.markdown(user_input)

    # Get and show the AI's reply, with full error handling (bonus feature)
    with st.chat_message("assistant"):
        with st.spinner("Thinking..."):
            try:
                reply = call_llm(user_input)
                st.markdown(reply)

            except ValueError as e:
                # Missing / invalid API key configuration
                st.error(f"⚠️ Configuration error: {e}")

            except AuthenticationError:
                st.error("⚠️ Authentication failed. Your API key appears to be invalid. "
                          "Please check the GROQ_API_KEY value in your .env file.")

            except APIConnectionError:
                st.error("⚠️ Network error: could not reach the Groq API. "
                          "Please check your internet connection and try again.")

            except APIError as e:
                st.error(f"⚠️ The API returned an error: {e}")

            except Exception as e:
                st.error(f"⚠️ An unexpected error occurred: {e}")
