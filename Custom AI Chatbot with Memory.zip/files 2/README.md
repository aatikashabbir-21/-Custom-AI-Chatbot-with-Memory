# 🤖 Custom AI Chatbot with Memory

A project built to learn **how to give an LLM-based chatbot memory** —
i.e., how to make it remember earlier messages in the same session and use
them as context for every new reply.

## 🎯 Objective

LLMs (like Llama models served by Groq) are **stateless** — every API call is independent and the
model has no idea what was said before, unless you tell it. This project
demonstrates the core technique used to solve that:

> Keep an in-memory list of every message exchanged (`user` and `assistant`
> turns). Every time you send a new message, append it to that list first,
> then send the **entire list** to the model as the `messages` parameter.
> When the model replies, append its reply to the list too — so the next
> request carries the full conversation forward.

This is exactly what ChatGPT-style apps do under the hood.

## 📁 Project Structure

```
Project1/
│
├── app.py              # Main web app (Streamlit) — chatbot with memory
├── terminal_app.py      # Bonus: terminal/CLI version of the same chatbot
├── requirements.txt      # Python dependencies
├── .env                  # Stores your API key (keep this secret!)
├── README.md             # This file
├── conversations/        # Auto-created folder where saved chats are stored
└── venv/                 # Your virtual environment (created by you)
```

## ✅ Features Implemented

**Core requirements:**
- Accepts user input (web chat box or terminal prompt)
- Sends input to an LLM (Groq API, running Llama 3.3 70B)
- Remembers previous messages during the session (`st.session_state` for
  the web app, a plain Python list for the terminal app)
- Uses the full previous conversation as context on every new request

**Bonus features:**
- 🗑️ **Clear chat history** — button in the web sidebar / `/clear` command in terminal
- 🎚️ **Limit stored messages** — a slider (web) / constant (terminal) that trims
  old messages so you don't exceed the model's token limit
- 💻 **Better terminal interface** — clean CLI with commands (`/clear`, `/save`,
  `/history`, `/exit`) in `terminal_app.py`
- 🌐 **Web interface (Streamlit)** — full chat UI in `app.py`
- 💾 **Saving conversations to a file** — saves full history as timestamped
  JSON in `conversations/`, plus a downloadable `.txt` transcript in the web app
- ⚠️ **Error handling** — gracefully handles a missing/invalid API key,
  authentication failures, and network/connection errors, in both apps

## 🔑 LLM Provider

This project uses the **Groq API**, which serves fast, free-tier-friendly
open models (like Meta's Llama 3.3 70B) through an OpenAI-compatible chat
endpoint. Get a free key at https://console.groq.com/keys — no credit card
needed for the free tier.

## 🛠️ Step-by-Step: How to Run This Project

### 1. Open the project folder
Extract/place the `Project1` folder anywhere on your computer, then open a
terminal (Command Prompt, PowerShell, or VS Code terminal) inside it:
```bash
cd Project1
```

### 2. Create a virtual environment
This keeps the project's Python packages separate from the rest of your system.

**Windows:**
```bash
python -m venv venv
venv\Scripts\activate
```

**Mac/Linux:**
```bash
python3 -m venv venv
source venv/bin/activate
```
You'll know it worked because your terminal prompt will now show `(venv)` at the start.

### 3. Install the dependencies
```bash
pip install -r requirements.txt
```

### 4. Add your API key
1. Get a free API key from https://console.groq.com/keys.
2. Open the `.env` file in the project folder.
3. Make sure it looks like this, with your real key:
```
GROQ_API_KEY=gsk_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```
4. Save the file. **Never share this file or commit it to GitHub** — anyone
   with your key can use your Groq quota.

### 5. Run the web app (Streamlit)
```bash
streamlit run app.py
```
This will automatically open the chatbot in your browser at `http://localhost:8501`.
Type a message, press Enter, and chat away — the bot will remember everything
you've said in the session.

### 6. (Bonus) Run the terminal version instead
```bash
python terminal_app.py
```
Then just type your messages at the `You:` prompt. Use `/clear`, `/save`,
`/history`, or `/exit` as needed.

### 7. Stopping the app
- Web app: go back to the terminal and press `Ctrl + C`.
- Terminal app: type `/exit` or press `Ctrl + C`.

### 8. Deactivate the virtual environment when done
```bash
deactivate
```

## 🔍 How the "Memory" Actually Works (Method Explanation)

1. **Storage:** We keep a Python list called `messages` (web) /
   `conversation_history` (terminal). Each entry is a dictionary:
   `{"role": "user" or "assistant", "content": "the text"}`.
2. **On every new user message:**
   - Append `{"role": "user", "content": user_input}` to the list.
   - (Optional) Trim the list to the last N messages, so we never exceed
     the model's context/token limit.
   - Send the **entire list** to `client.messages.create(..., messages=list)`.
3. **On every model reply:**
   - Append `{"role": "assistant", "content": ai_reply}` to the same list.
4. **Repeat.** Because the whole list is resent every time, the model can
   "see" everything said earlier in the session and respond accordingly —
   even though the model itself has no built-in memory.
5. **Session-only memory:** This history lives only in RAM
   (`st.session_state` or a Python variable), so it resets when you restart
   the app — unless you use the **Save Chat** feature, which writes it to a
   JSON file in `conversations/` for permanent storage.

## 🧯 Troubleshooting

| Problem | Fix |
|---|---|
| `ModuleNotFoundError: No module named 'streamlit'` | Run `pip install -r requirements.txt` again, make sure your venv is activated |
| "No valid API key found" | Check that `.env` has `GROQ_API_KEY=` followed by your real key, with no quotes or spaces |
| Authentication error | Your API key is invalid or expired — generate a new one from https://console.groq.com/keys |
| Network error | Check your internet connection; some networks/firewalls block API calls |
| App remembers nothing after refresh | This is expected — memory is per-session. Use "Save Chat" before closing if you want to keep it |

## 📚 What You Should Learn From This Project

- How LLM APIs are stateless and why conversation history must be resent manually.
- How to structure a `messages` list for a chat-based LLM API.
- How to manage state in a Streamlit app using `st.session_state`.
- How to handle real-world errors (bad keys, no internet) gracefully instead
  of letting the program crash.
- How the same underlying logic (a list + API call) can power both a web
  UI and a terminal UI.
